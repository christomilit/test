<?php 

class User_model {
    private $nama = 'Contoh nama';

    public function getUser()
    {
        return $this->nama;
    }
}