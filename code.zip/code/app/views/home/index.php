<div class="container">
    <div class="jumbotron mt-4">
      <h1 class="display-4">The Warehouse!</h1>
      <p class="lead">Program untuk memenuhi UAS Pemrograman Framework </p>
      <hr class="my-4">
      <p>Klik tombol dibawah ini untuk memasuki Warehouse.</p>
      <a class="btn btn-primary btn-lg" href="<?= BASEURL; ?>/Barang" role="button">Data Barang</a>
    </div>
</div>